// generated from rosidl_generator_c/resource/idl.h.em
// with input from fleet:action/FleetManagement.idl
// generated code does not contain a copyright notice

#ifndef FLEET__ACTION__FLEET_MANAGEMENT_H_
#define FLEET__ACTION__FLEET_MANAGEMENT_H_

#include "fleet/action/detail/fleet_management__struct.h"
#include "fleet/action/detail/fleet_management__functions.h"
#include "fleet/action/detail/fleet_management__type_support.h"

#endif  // FLEET__ACTION__FLEET_MANAGEMENT_H_
