#ifndef FLEET_MANAGEMENT_SIMPLE_ACTION_CLIENT_H
#define FLEET_MANAGEMENT_SIMPLE_ACTION_CLIENT_H

#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <actionlib/server/simple_action_server.h>
#include <action/fleet_management.hpp>

class FleetManagementSimpleActionClient {
public:
    FleetManagementSimpleActionClient();

    // Initialize the action client
    void initialize();

    // Send a goal to the action server
    void sendGoal();

    // Cancel the goal
    void cancelGoal();

private:
    rclcpp::Node::SharedPtr node_;
    rclcpp_action::Client<fleet_management_msgs::action::FleetManagement>::SharedPtr action_client_;
};

#endif // FLEET_MANAGEMENT_SIMPLE_ACTION_CLIENT_H

