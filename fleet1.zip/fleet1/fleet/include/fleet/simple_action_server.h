#ifndef FLEET_MANAGEMENT_SIMPLE_ACTION_SERVER_H
#define FLEET_MANAGEMENT_SIMPLE_ACTION_SERVER_H

#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <actionlib/server/simple_action_server.h>
#include <action/fleet_management.hpp>

class FleetManagementSimpleActionServer {
public:
    FleetManagementSimpleActionServer();

    // Initialize the action server
    void initialize();

private:
    rclcpp::Node::SharedPtr node_;
    rclcpp_action::Server<fleet_management_msgs::action::FleetManagement>::SharedPtr action_server_;

    // Callback to handle action goals
    rclcpp_action::GoalResponse handleGoal(
        const rclcpp_action::GoalUUID &uuid,
        std::shared_ptr<const fleet_management_msgs::action::FleetManagement::Goal> goal);

    // Callback to handle action cancellations
    rclcpp_action::CancelResponse handleCancel(
        const std::shared_ptr<rclcpp_action::ServerGoalHandle<fleet_management_msgs::action::FleetManagement>> goal_handle);

    // Callback to execute the action
    void execute(const std::shared_ptr<rclcpp_action::ServerGoalHandle<fleet_management_msgs::action::FleetManagement>> goal_handle);
};

#endif // FLEET_MANAGEMENT_SIMPLE_ACTION_SERVER_H

