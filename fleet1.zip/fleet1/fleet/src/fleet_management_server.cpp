#include "rclcpp/rclcpp.hpp"
#include "actionlib/server/simple_action_server.h"
#include "action/fleet_management.hpp"

class FleetManagementServer : public rclcpp::Node
{
public:
  using FleetManagement = fleet_management_msgs::action::FleetManagement;
  using GoalHandle = rclcpp_action::ServerGoalHandle<FleetManagement>;

  FleetManagementServer()
    : Node("fleet_management_server"),
      action_server_(this, "fleet_management", std::bind(&FleetManagementServer::handleGoal, this, std::placeholders::_1), false)
  {
    action_server_.register_goal_callback(std::bind(&FleetManagementServer::handleGoal, this, std::placeholders::_1));
    action_server_.register_preempt_callback(std::bind(&FleetManagementServer::handlePreempt, this));
    action_server_.start();
  }

private:
  void handleGoal(const GoalHandle::SharedPtr goal)
  {
    rclcpp::Rate rate(1);
    const auto goal_msg = goal->get_goal();
    auto result = std::make_shared<FleetManagement::Result>();

    // Simulate fleet management
    for (int i = 0; i < goal_msg->fleet_size; ++i)
    {
      // Your fleet management logic here

      // Simulate updating vehicle routes
      result->vehicle_routes.push_back(i * 100);
    }

    result->operation_success = true;
    result->message = "Fleet management completed successfully";

    goal->succeed(result);
  }

  void handlePreempt()
  {
    RCLCPP_INFO(get_logger(), "Goal preempted");
    action_server_.set_preempted();
  }

  rclcpp_action::Server<FleetManagement>::SharedPtr action_server_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<FleetManagementServer>());
  rclcpp::shutdown();
  return 0;
}

