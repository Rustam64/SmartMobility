#include "rclcpp/rclcpp.hpp"
#include "actionlib/client/simple_action_client.h"
#include "action/fleet_management.hpp"

class FleetManagementClient : public rclcpp::Node
{
public:
  using FleetManagement = fleet_management_msgs::action::FleetManagement;

  FleetManagementClient()
    : Node("fleet_management_client"),
      action_client_(rclcpp_action::create_client<FleetManagement>(this, "fleet_management"))
  {
    while (!action_client_->wait_for_server(std::chrono::seconds(5)))
    {
      RCLCPP_INFO(get_logger(), "Waiting for action server to come up...");
    }
  }

  void sendGoal(int fleet_size)
  {
    auto goal_msg = FleetManagement::Goal();
    goal_msg.fleet_size = fleet_size;

    auto send_goal_options = rclcpp_action::Client<FleetManagement>::SendGoalOptions();
    send_goal_options.goal_response_callback =
        std::bind(&FleetManagementClient::goalResponseCallback, this, std::placeholders::_1);
    send_goal_options.feedback_callback =
        std::bind(&FleetManagementClient::feedbackCallback, this, std::placeholders::_1, std::placeholders::_2);
    send_goal_options.result_callback =
        std::bind(&FleetManagementClient::resultCallback, this, std::placeholders::_1);

    auto goal_handle_future = action_client_->async_send_goal(goal_msg, send_goal_options);
  }

private:
  void goalResponseCallback(const std::shared_future<GoalHandle::SharedPtr> &goal_handle)
  {
    if (goal_handle.get())
    {
      RCLCPP_INFO(get_logger(), "Goal accepted");
    }
    else
    {
      RCLCPP_INFO(get_logger(), "Goal rejected");
    }
  }

  void feedbackCallback(
      GoalHandle::SharedPtr,
      const std::shared_future<FleetManagement::Feedback> &feedback)
  {
    RCLCPP_INFO(get_logger(), "Received feedback: %d", feedback.get()->completed_routes);
  }

  void resultCallback(const GoalHandle::WrappedResult &result)
  {
    switch (result.code)
    {
      case rclcpp_action::ResultCode::SUCCEEDED:
        RCLCPP_INFO(get_logger(), "Goal succeeded");
        break;
      case rclcpp_action::ResultCode::ABORTED:
        RCLCPP_INFO(get_logger(), "Goal was aborted");
        break;
      case rclcpp_action::ResultCode::CANCELED:
        RCLCPP_INFO(get_logger(), "Goal was canceled");
        break;
      default:
        RCLCPP_INFO(get_logger(), "Unknown result code");
        break;
    }
  }

  rclcpp_action::Client<FleetManagement>::SharedPtr action_client_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto fleet_size = 5; // Set the desired fleet size here
  auto client_node = std::make_shared<FleetManagementClient>();
  client_node->sendGoal(fleet_size);
  rclcpp::spin(client_node);
  rclcpp::shutdown();
  return 0;
}

