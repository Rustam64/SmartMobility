from setuptools import setup

setup(
    name='my_fleet_management',  # Replace with your package name
    version='0.0.1',
    packages=['my_fleet_management'],  # Replace with your package name
    install_requires=['setuptools'],
    zip_safe=True,
    author='Rustam',
    author_email='rrakhimov64@gmail.com',
    maintainer='Rustam',
    maintainer_email='rrakhimov64@gmail.com',
    description='ROS2 Fleet management',
    license='License',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'fleet_management_client = my_fleet_management.fleet_management_client:main',
            'fleet_management_server = my_fleet_management.fleet_management_server:main',
        ],
    },
)

