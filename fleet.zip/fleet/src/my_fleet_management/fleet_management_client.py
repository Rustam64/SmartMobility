import rclpy
from rclpy.action import ActionClient
from your_package.msg import FleetManagement

def main(args=None):
    rclpy.init(args=args)
    node = rclpy.create_node('fleet_management_client')
    action_client = ActionClient(node, FleetManagement, 'fleet_management')  # Specify the action name

    # Create a goal with the desired fleet size and other parameters
    goal_msg = FleetManagement.Goal()
    goal_msg.fleet_size = 10  # Set your desired fleet size
    # Populate other goal fields as needed

    # Send the goal
    future = action_client.send_goal_async(goal_msg)

    # Wait for the result (this is a non-blocking call)
    rclpy.spin_until_future_complete(node, future)

    if future.result():
        result = future.result().result
        # Process the result, e.g., vehicle routes, success status, etc.
        print("Fleet management result:", result)
    else:
        print("Action call failed to complete")

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

